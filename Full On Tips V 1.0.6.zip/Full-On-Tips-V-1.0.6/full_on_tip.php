<?php
/**
 * @package woo_cambio
 * @version 1.0
 */
/*
Plugin Name: Full On Tips
Plugin URI: https://fullonplugins.com/ 
Description: Adds a field on the woocommerce checkout that allows your customers to add a tip to the order.
Author: Full On Plugins
Version: 1.0.6
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: full-on-tips
*/

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

if( ! function_exists('db_plugin_tip')){

	function db_plugin_tip() {

		global $wpdb;
		$nombreTabla = $wpdb->prefix . "config_tip";

		$created = dbDelta(  
		  "CREATE TABLE IF NOT EXISTS $nombreTabla (
			ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			nombre varchar(60) NOT NULL DEFAULT '0px',
			height varchar(64) NOT NULL DEFAULT '0px',
			width varchar(64) NOT NULL DEFAULT '0px',
			color varchar(64) NOT NULL DEFAULT '0',	
			fuente varchar(64) NOT NULL DEFAULT '0',		
			PRIMARY KEY (ID),
			KEY nombre (nombre)
		  ) CHARACTER SET utf8 COLLATE utf8_general_ci;"
		);
	} 

	register_activation_hook( __FILE__, 'db_plugin_tip' );
}

if( ! function_exists('wc_menu_tip')){

	add_action('admin_menu','wc_menu_tip');
	// add_action('init','ammar');
	function ammar(){
		echo "string";
		exit();
	}
	function wc_menu_tip() {

		add_menu_page(
			'Menu Tips',
			'Full on Tips',
			'manage_options',
			'menu_tip',
			'wc_cambio_display'
			// '',
			// '15',
		);
	}
}

add_action( 'wp_enqueue_scripts', 'add_my_script' );
function add_my_script() {
       wp_enqueue_script(
           'your-script', // name your script so that you can attach other scripts and de-register, etc.
           get_template_directory_uri() . 'custom-JQuery.js', // this is the location of your script file
           array('jquery') // this array lists the scripts upon which your script depends
       );
}

function wc_cambio_display() {

	wp_register_style('prefix_bootstrap', '//maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
	wp_enqueue_style('prefix_bootstrap');
	wp_register_script('prefix_bootstrap_1', '//maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');
	wp_enqueue_script('prefix_bootstrap_1');
	wp_register_script('prefix_bootstrap_2', '//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js');
	wp_enqueue_script('prefix_bootstrap_2');
	wp_register_script('prefix_bootstrap_3', '//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"');
	wp_enqueue_script('prefix_bootstrap_3');

	global $wpdb; // Este objeto global permite acceder a la base de datos de WP
    // Si viene del formulario  graba en la base de datos
	// Cuidado con el último igual de la condición del if que es doble
	$btn_1 = $wpdb->get_results( "SELECT id,nombre, width, height, color,fuente FROM wp_config_tip where id = 1" );
	$btn_2 = $wpdb->get_results( "SELECT id,nombre, width, height, color,fuente FROM wp_config_tip where id = 2" );
	//echo "Registro #1. Nombre: " . $registros[0]->nombre . ", Width: " . $registros[0]->width .  ", Height: " . $registros[0]->height . "<br/>";
	
	if ($_POST['txtwidth'] != '' AND $_POST['txtheight'] != '') 
	{
		$tabla_cambio = $wpdb->prefix . 'config_tip'; 
		
        $width = sanitize_text_field($_POST['txtwidth']);
		$height = sanitize_text_field($_POST['txtheight']);
		$color = sanitize_text_field($_POST['micolor']);
		$fuente = sanitize_text_field($_POST['micolor_f']);
		$cf_1 = sanitize_text_field($_POST['name_cf_1']);
		$cfu_1 = sanitize_text_field($_POST['name_cfu_1']);
	
		if($cf_1 == "on"){
			$color = '0';
		}

		if($cfu_1 == "on"){
			$fuente = '0';
		}
					
		$wpdb->update(   $tabla_cambio, 
		    array( 
				'width' => $width,
				'height' => $height,
				'color' => $color,
				'fuente' => $fuente
		    ),
		    array( 'ID' => 1 )
		);

		$width = sanitize_text_field($_POST['txtwidth_2']);
		$height = sanitize_text_field($_POST['txtheight_2']);
		$color = sanitize_text_field($_POST['micolor_2']);  
		$fuente = sanitize_text_field($_POST['micolor_f_2']);
		$cf_2 = sanitize_text_field($_POST['name_cf_2']);
		$cfu_2 = sanitize_text_field($_POST['name_cfu_2']);  

		if($cf_2 == "on"){
			$color = '0';
		}

		if($cfu_2 == "on"){
			$fuente = '0';
		}
		 
		$wpdb->update( $tabla_cambio, 
		  array( 
			  'width' => $width,
			  'height' => $height,
			  'color' => $color,
			  'fuente' => $fuente
		  ),
		  array( 'ID' => 2 )
		  );
		?>
			<script type="text/javascript">
				var $j = jQuery.noConflict();
				$j(function(){
					$j( document ).ready(function( $ ) {		
						$j("#msgexito").fadeOut(5000); 
					});
				});
    		</script>	
    	<?php
		?>
		<br>
			<div class="row ">				
				<div class="alert alert-success alert-dismissible fade show" onClick="muestra_oculta('msgexito')" id="msgexito" role="alert" style="display:true;">
					your data has been successfully registered
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    					<span aria-hidden="true">&times;</span>
  					</button>
				</div>				
			</div>
		<?php
		$btn_1 = $wpdb->get_results( "SELECT id,nombre, width, height, color,fuente FROM wp_config_tip where id = 1" );
		$btn_2 = $wpdb->get_results( "SELECT id,nombre, width, height, color,fuente FROM wp_config_tip where id = 2" );
    }
// Esto que viene ya lo debes tener escrito del primer paso    
    ob_start();
	?>
		<style>
			.fuente {
				font-family:courier;
			}
			.oscura{
				font-weight: bold;
			}	
		</style>
		<script type="text/javascript">
			var $j = jQuery.noConflict();
			$j(function(){
				$j( document ).ready(function( $ ) {	
					$("#txtwidth").blur(function(){
						if(this.value.indexOf("px") == -1){
	   						this.value = this.value + "px" ;      
   						}
					 });
					$("#txtheight").blur(function(){
						if(this.value.indexOf("px") == -1){
	   						this.value = this.value + "px" ;      
   						}
		 			});
					$("#txtwidth_2").blur(function(){
						if(this.value.indexOf("px") == -1){
	   						this.value = this.value + "px" ;      
   						}
					 });
					 $("#txtheight_2").blur(function(){
						if(this.value.indexOf("px") == -1){
	   						this.value = this.value + "px" ;      
   						}
		 			});	
				});
			});
    	</script>	
		<div class="wrap">
			<h1><?php _e( 'Menu for configuring TIP buttons', 'menu_tip' ); ?></h1>
		</div>      
		               
		<form action="<?php get_the_permalink(); ?>" method="post" id="woocambio">
			<label class="fuente oscura" for="txtnombre">Button ADD UPDATE:</label>
			<br>
			<div class="row fuente">
				<div class="col-3">
    				<label for="txtwidth">Width :</label>
					<input type="text" id="txtwidth" name="txtwidth" value = "<?php echo $btn_1[0]->width  ?>" >
    			</div>
    			<div class="col-3">
    				<label for="txtheight">Height:</label>
					<input type="text" id="txtheight" name="txtheight" value = "<?php echo $btn_1[0]->height  ?>">
    			</div>
    			<div class="col-3 ">
    				<label for="micolor">Background color:</label>
					<input type="color" name="micolor" id="micolor" value = "<?php echo $btn_1[0]->color  ?>"/>
					<div class="custom-control custom-switch text-left" >
						<input type="checkbox" class="custom-control-input " id="cf_1" name="name_cf_1" checked>
						<label class="custom-control-label" for="cf_1">Default</label>
					</div>					
				</div>	
				<div class="col-3 ">
					<label for="micolor">Font Color:</label>
					<input type="color" name="micolor_f" id="micolor_f" value = "<?php echo $btn_1[0]->fuente  ?>"/>
					<div class="custom-control custom-switch text-left" >
						<input type="checkbox" class="custom-control-input" id="cfu_1" name="name_cfu_1" checked>
						<label class="custom-control-label" for="cfu_1">Default</label>
					</div>
				</div>   					
				<br>
			</div>
			<br>
			<hr>
			<br>
			<label class="fuente oscura" for="txtnombre">Button DELETE</label>
			<br>
			<div class="row fuente">
				<div class="col-3">
					<label for="txtwidth_2">Width :</label>
					<input type="text" id="txtwidth_2" name="txtwidth_2" value = "<?php echo $btn_2[0]->width  ?>" >	
    			</div>
    			<div class="col-3">
					<label for="txtheight_2">Height:</label>
					<input type="text" id="txtheight_2" name="txtheight_2" value = "<?php echo $btn_2[0]->height  ?>">	
    			</div>
    			<div class="col-3">
					<label for="micolor">Background color:</label>
					<input type="color" name="micolor_2" id="micolor_2"  value = "<?php echo $btn_2[0]->color ?>" />
					<div class="custom-control custom-switch text-left" >
						<input type="checkbox" class="custom-control-input " id="cf_2" name="name_cf_2" checked>
						<label class="custom-control-label" for="cf_2">Default</label>
					</div>
				</div>	
				<div class="col-3">
					<label for="micolor">Font Color:</label>
					<input type="color" name="micolor_f_2" id="micolor_f_2"  value = "<?php echo $btn_2[0]->fuente ?>" />	
					<div class="custom-control custom-switch text-left" >
						<input type="checkbox" class="custom-control-input" id="cfu_2" name="name_cfu_2"  checked>
						<label class="custom-control-label" for="cfu_1">Default</label>
					</div>
    			</div>		
				<br>				
			</div>			
			<br>
			<hr>
			<br>			
			<div class="product_custom_field">
					<div class="row " >
						<div class="col-2 text-center">
						</div>
						<div class="col-8 alert alert-dark border border-secondary" role="alert">
								<div class="row">
									<div class="col-4 text-center">
									</div>
									<div class="col-2 text-center">
						 				<a class="button" style=" 	<?php if ($btn_1[0]->width <> '0px'){?>  width: <?php echo $btn_1[0]->width; ?>; <?php }  ?>
														 	<?php if ($btn_1[0]->height <> '0px'){ ?>  height: <?php echo $btn_1[0]->height; ?>; <?php } ?>
															<?php if ($btn_1[0]->color <> '0'){ ?>  background-color: <?php echo $btn_1[0]->color; ?>; <?php } ?>
															<?php if ($btn_1[0]->fuente <> '0'){ ?>  color: <?php echo $btn_1[0]->fuente; ?>; <?php } ?>
														" 
														id= "boton-save">-- ADD TIP --</a>

						 			</div>
						 			<div class="col-2 text-center">
						 				<a class="button" style="	<?php if ($btn_2[0]->width <> '0px'){?>  width: <?php echo $btn_2[0]->width; ?>; <?php } ?>
																<?php if ($btn_2[0]->height <> '0px'){ ?>  height: <?php echo $btn_2[0]->height; ?>; <?php } ?>
																<?php if ($btn_2[0]->color <> '0'){ ?>  background-color: <?php echo $btn_2[0]->color; ?>; <?php } ?>
																<?php if ($btn_2[0]->fuente <> '0'){ ?>  color: <?php echo $btn_2[0]->fuente; ?>; <?php } ?>
														" 
														id= "boton-delete">DELETE TIP</a>
									</div>
									<div class="col-4 text-center">
									</div>
								</div>														
						</div>
						<div class="col-2 text-center">
						</div>
					</div>
					
				</div>
			<br>
			<br>		
			
  	
			<div class="text-center">
				<input class='btn btn-outline-success btn-lg' type="submit"  id="save" value="SAVE">
			</div>
	    	
		</form>
	<?php
	
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

add_action( 'woocommerce_review_order_before_payment', 'agrega_mi_campo_personalizado' );

function agrega_mi_campo_personalizado( $checkout ) {

	global $wpdb; 
	$btn_1 = $wpdb->get_results( "SELECT id,nombre, width, height, color,fuente FROM wp_config_tip where id = 1" );
	$btn_2 = $wpdb->get_results( "SELECT id,nombre, width, height, color,fuente FROM wp_config_tip where id = 2" );

	woocommerce_form_field( 'dato', array(
		'id'=> 'dato',
		'type' => 'text',
		'class' => array('my-field-class form-row-wide'),
		'label' => __('Add Tip'),
		)
	
	);
		
	?>	
	<style>
		#boton-save {
			text-decoration:none;
			color:white;
			padding:10px 25px; 
			background-color:#FF9800;
			display:inline-block
		}
	
		#boton-save:hover {
			background-color:#333333;
		}	
	</style>
		
		<div class="product_custom_field">
			<row >
			<a class="button" style=" 	<?php if ($btn_1[0]->width <> '0px'){?>  width: <?php echo $btn_1[0]->width; ?>; <?php }  ?>
									 	<?php if ($btn_1[0]->height <> '0px'){ ?>  height: <?php echo $btn_1[0]->height; ?>; <?php } ?>
										 <?php if ($btn_1[0]->color <> '0'){ ?>  background-color: <?php echo $btn_1[0]->color; ?>; <?php } ?>
									" 
									id= "boton-save">-- ADD TIP --</a>
			</row>
			<row >
				<a class="button" style="	<?php if ($btn_2[0]->width <> '0px'){?>  width: <?php echo $btn_2[0]->width; ?>; <?php } ?>
											<?php if ($btn_2[0]->height <> '0px'){ ?>  height: <?php echo $btn_2[0]->height; ?>; <?php } ?>
											<?php if ($btn_2[0]->color <> '0'){ ?>  background-color: <?php echo $btn_2[0]->color; ?>; <?php } ?>
									" 
									id= "boton-delete">DELETE TIP</a>
			</row>
		</div>
		<br>				
	
	<?php
	?>
		<div style="display: none">
			<?php
				woocommerce_form_field( 'checky', array(
				'type' => 'checkbox',
				'class' => array('my-field-class form-row-wide'),
				'label' => __('Aplicar TIP'),
				));
			?>
		</div>
	<?php

}

add_action( 'woocommerce_checkout_update_order_meta', 'actualizar_info_pedido_con_nuevo_campo' );

function actualizar_info_pedido_con_nuevo_campo( $order_id ) {
	update_post_meta( $order_id, 'CHECKY', sanitize_text_field( $_POST['checky'] ) );
}

add_action( 'woocommerce_admin_order_data_after_billing_address', 'mostrar_campo_personalizado_en_admin_pedido', 10, 1 );

function mostrar_campo_personalizado_en_admin_pedido($order){
echo '

	<strong>'.__('TIPS').':</strong> ' . get_post_meta( $order->id, 'CHECKY', true ) . '

';
}

add_action( 'wp_footer', 'woocommerce_add_custom_extra', 357 );

add_action( 'wp_footer', 'woocommerce_add_custom_extra', 357 );
function woocommerce_add_custom_extra() {
    if (is_checkout()) {
    	?>
			<script type="text/javascript">
				var $j = jQuery.noConflict();
				$j(function(){
					$j( document ).ready(function( $ ) {

						$j('#dato').on( "keydown", function(event) {
							if($(this).val().length == 0 ) {
    		            		$(this).val($(this).val()+"$")                		
    		        		}
    					});
						$j('#checky').click(function(){
							$j('body').trigger('update_checkout');
						});
						$j('#boton-cart').click(function(){									
    		    			$j("[name='update_cart']").trigger("click"); 
							alert('en el carrito');
						});
						$j('#boton-save').click(function(){
							valor = $j('#dato').val().replace('$','');
							if(	valor>0){
								$j('#boton-save').html('UPDATE TIP');
							}					
							$j('#checky').prop("checked", true);
							$j('body').trigger('update_checkout');
						});
						$j('#boton-delete').click(function(){
							$j('#checky').prop("checked", false);
							$j('#dato').val('');
							$j('#boton-save').html('-- ADD TIP --');
							$j('body').trigger('update_checkout');
						});
					});
				});
    		</script>	
    	<?php
	}

}

add_action( 'woocommerce_cart_calculate_fees', 'woo_add_custom_extra', 43, 1);
function woo_add_custom_extra( $cart ){

    if ( ! $_POST || ( is_admin() && ! is_ajax() ) ) {
        return;
    }
    if ( isset( $_POST['post_data'] ) ) {
        parse_str( $_POST['post_data'], $post_data );
    } else {
        $post_data = $_POST;
	}
	$valor=$post_data['dato'];
	$valor=str_replace("$", "", $valor);
	if (isset($post_data['checky']) && $valor>0) {		
		$extracost = $valor;
		WC()->cart->add_fee( 'TIPS',$extracost);
	}
	
}